import React from 'react'
import { Grid, Paper, TextField ,Button } from '@mui/material'
import GoogleIcon from '@mui/icons-material/Google';
import FacebookIcon from '@mui/icons-material/Facebook';
import CallIcon from '@mui/icons-material/Call';
import { Link } from 'react-router-dom';



const SignUp = () => {

  const paperstyle={
    height:'92vh',
    padding:20,
    width:280,
    margin:'40px auto',
  }
  const makebutton={
    margin:'20px auto',
    backgroundColor:"lightgrey",
    color:"black",
    
  }
  const link ={
    textDecoration:"none",
    color:"green",
    marginLeft:"6.5rem",
  }
  return (
    <Grid>
             <Paper elevation={10} style={paperstyle}>
               <h2>SignUp</h2>
               <p>Welcome to Instacart!Enter your Email to get started</p>
               <TextField  label='Email' variant="standard" placeholder='Enter email' fullWidth></TextField>
               <p>By continuing you agree to our <Link style={{color:'green',textDecoration:"none"}}>terms of services</Link> & <Link style={{color:'green',textDecoration:"none"}}>privacy policy</Link></p>
              

                  <Button variant="contained" fullWidth style={{backgroundColor:"green",color:'white'}}>
                  Continue
                      </Button>
                      <p align='center'>or</p>
                      <Button  className='btn' startIcon={<GoogleIcon/>}variant="contained"fullWidth style={{backgroundColor:"lightgrey",color:'black'}}>
                       Continue with Google
                      </Button>
                      
                      <Button  startIcon={<FacebookIcon/>}variant="contained" fullWidth style={makebutton}>
                       Continue with Facebook
                      </Button>
                      <Button   startIcon={<CallIcon/>}variant="contained"fullWidth style={{backgroundColor:"lightgrey",color:'black'}} >
                       Continue with Phone
                      </Button>
                      <p align="center"> Already have account?</p>
                      <Link to="/Login" style={link}>
                       Log in
                      </Link>
              </Paper>


    </Grid>

  )
}

export default SignUp
