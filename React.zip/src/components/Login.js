
import React from 'react'
import './login.css'
import { Grid, Paper, TextField ,Button, } from '@mui/material'
import GoogleIcon from '@mui/icons-material/Google';
import FacebookIcon from '@mui/icons-material/Facebook';
import { Link } from 'react-router-dom';


const Login = () => {

    const paperstyle={
      height:'80vh',
      padding:20,
      width:280,
      margin:'40px auto',
    }
    const makebutton={
      margin:'20px auto',
      backgroundColor:"lightgrey",
      color:"black",
      
      
    }
    

  return (
    <Grid>
             <Paper elevation={10} style={paperstyle}>
               <h2>Log in</h2>
               <TextField  label='Email' variant="standard" placeholder='Enter email' fullWidth></TextField>
               <TextField  label='Password' variant="standard" placeholder='Enter password' fullWidth></TextField>
                <p>Forget password? 
                  <Link to="/" style={{color:'green',textDecoration:"none"}}>   Reset it </Link></p>

                  <Button variant="contained" fullWidth style={{backgroundColor:"green",color:'white'}}>
                       Log in
                      </Button>
                      <p  align='center'>or</p>
                      <Button   startIcon={<GoogleIcon className="icons"/>}variant="contained"fullWidth style={{backgroundColor:"lightgrey",color:'black'}} >
                       Continue with Google
                      </Button>
                      
                      <Button  startIcon={<FacebookIcon/>}variant="contained" fullWidth style={makebutton}>
                       Continue with Facebook
                      </Button>
                      
                      <p align="center"> Don't have account?</p>
                      <Link to="/Signup" style={{color:"green",marginLeft:"6.5rem",textDecoration:"none"}}>
                        Sign up 
                      
                       </Link>
                 </Paper>
    </Grid>

        
    
  )
}

export default Login

